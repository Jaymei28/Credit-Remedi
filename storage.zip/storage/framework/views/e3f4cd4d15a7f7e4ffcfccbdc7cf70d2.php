<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Credit Remedi'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <style>
        /* Navbar tour styles */
        .navbar-tour-highlight {
            background-color: #ffffff !important;
            color: #2a7ae4 !important;
            border-radius: 6px;
            padding: 4px 8px;
            position: relative;
            z-index: 10000;
        }

        /* Popup and arrow */
        #navbarTourPopup {
            position: absolute;
            background: white;
            color: #333;
            padding: 16px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 9999;
            max-width: 260px;
            text-align: center;
            font-size: 14px;
            display: none;
        }

        #navbarTourArrow {
            display: none;
            position: absolute;
            width: 0;
            height: 0;
            border-left: 10px solid transparent;
            border-right: 10px solid transparent;
            border-top: 10px solid white;
            z-index: 9998;
        }

        #navbarTourBackdrop {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 9997;
        }

        #navbarTourPopup button {
            background: #2a7ae4;
            color: white;
            border: none;
            padding: 8px 12px;
            margin-top: 12px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2">
                <img src="<?php echo e(asset('4-removebg-preview.png')); ?>" alt="Credit Remedi Logo" style="height: 46px;">
            </a>

            <!-- Dark Mode Toggle - Always Visible on Mobile -->
            <div class="d-flex align-items-center gap-2 order-lg-last">
                <div class="theme-toggle-wrapper">
                    <input type="checkbox" id="theme-toggle-checkbox" class="theme-toggle-checkbox">
                    <label for="theme-toggle-checkbox" class="theme-toggle-label">
                        <span class="theme-toggle-icon sun">☀️</span>
                        <span class="theme-toggle-icon moon">🌙</span>
                        <span class="theme-toggle-slider"></span>
                    </label>
                </div>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar"
                    aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>

            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto mt-2 mt-lg-0">
                    <li class="nav-item mx-0 <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link text-white px-2 py-2" style="white-space: nowrap; font-size: 0.9rem; font-weight: 500;">Dashboard</a>
                    </li>
                    <li class="nav-item mx-0 <?php echo e(request()->routeIs('disputes.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('disputes.index')); ?>" class="nav-link text-white px-2 py-2" style="white-space: nowrap; font-size: 0.9rem; font-weight: 500;">
                            Disputes
                        </a>
                    </li>
                    <?php if(auth()->user()->plan_type === 'premium' || auth()->user()->role === 'admin'): ?>
                        <li class="nav-item mx-0 <?php echo e(request()->routeIs('credit-repair-bot') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('credit-repair-bot')); ?>" class="nav-link text-warning px-2 py-2" style="white-space: nowrap; font-size: 0.9rem; font-weight: 500;">
                                <i class="bi bi-robot"></i> AI Chat
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(in_array(auth()->user()->plan_type, ['pro', 'premium']) || auth()->user()->role === 'admin'): ?>
                        <li class="nav-item mx-0 <?php echo e(request()->routeIs('fundability.*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('fundability.index')); ?>" class="nav-link text-info px-2 py-2" style="white-space: nowrap; font-size: 0.9rem; font-weight: 500;">
                                <i class="bi bi-graph-up-arrow"></i> Funding
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item mx-0 <?php echo e(request()->routeIs('credit-vault') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('credit-vault')); ?>" class="nav-link text-white px-2 py-2" style="white-space: nowrap; font-size: 0.9rem; font-weight: 500;">Vault</a>
                    </li>
                    <li class="nav-item mx-0 <?php echo e(request()->routeIs('identityiq.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('identityiq.import')); ?>" class="nav-link text-white px-2 py-2" style="white-space: nowrap; font-size: 0.9rem; font-weight: 500;">
                            IdentityIQ
                        </a>
                    </li>
                    <li class="nav-item mx-0 <?php echo e(request()->routeIs('resource-center') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('resource-center')); ?>" class="nav-link text-white px-2 py-2" style="white-space: nowrap; font-size: 0.9rem; font-weight: 500;">Resources</a>
                    </li>
                </ul>

                <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                    <?php if(Auth::user()->role === 'admin'): ?>
                        <li class="nav-item <?php echo e(request()->routeIs('admin.waitlist.report') ? 'active' : ''); ?>">
                            <a class="nav-link text-white small <?php echo e(request()->routeIs('admin.waitlist.report') ? 'active' : ''); ?>" href="<?php echo e(route('admin.waitlist.report')); ?>">Waitlist Report</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">
                            <a class="nav-link text-white small <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">Users</a>
                        </li>
                    <?php endif; ?>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-white small" href="#" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->name ?? 'Account'); ?>

                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item small" href="/profile">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a href="#" class="dropdown-item small text-danger" id="unsubscribe-btn">
                                    Unsubscribe
                                </a>
                            </li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item small">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Guided Tour Elements -->
    <div id="navbarTourBackdrop"></div>
    <div id="navbarTourPopup">
        <div id="navbarTourText">Welcome to the navbar tour.</div>
        <button onclick="nextNavbarTourStep()">Next ➡️</button>
    </div>
    <div id="navbarTourArrow"></div>

    <!-- Page Content -->
    <main class="container mt-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script>
        const navbarTourSteps = [
            { selector: 'a[href="<?php echo e(route('dashboard')); ?>"]', text: '📊 Dashboard — your main control center.' },
            { selector: 'a[href="<?php echo e(route('disputes.index')); ?>"]', text: '📁 Manage your credit disputes here.' },
            <?php if(auth()->user()->has_paid || auth()->user()->role === 'admin'): ?>
                { selector: 'a[href="<?php echo e(route('credit-repair-bot')); ?>"]', text: '🤖 Credit Remedi AI — your smart assistant for credit repair.' },
            <?php endif; ?>
            { selector: 'a[href="<?php echo e(route('credit-vault')); ?>"]', text: '🔐 Credit Vault — your go-to place for all guide videos, tutorials, and helpful links. Everything you need to understand and use the platform is stored here securely.' },
            { selector: 'a[href="<?php echo e(route('resource-center')); ?>"]', text: '📚 Find helpful guides and documents in the Resource Center.' }
        ];

        let navbarTourIndex = 0;

        function startNavbarTour() {
            if (localStorage.getItem('navbarTourCompleted')) return;

            navbarTourIndex = 0;
            document.getElementById('navbarTourBackdrop').style.display = 'block';
            document.getElementById('navbarTourPopup').style.display = 'block';
            document.getElementById('navbarTourArrow').style.display = 'block';

            showNavbarTourStep(navbarTourIndex);
        }

        function showNavbarTourStep(index) {
            document.querySelectorAll('.navbar-tour-highlight').forEach(el => el.classList.remove('navbar-tour-highlight'));

            const step = navbarTourSteps[index];
            const el = document.querySelector(step.selector);
            const popup = document.getElementById('navbarTourPopup');
            const arrow = document.getElementById('navbarTourArrow');

            if (!el) return;

            el.classList.add('navbar-tour-highlight');
            document.getElementById('navbarTourText').innerText = step.text;

            const rect = el.getBoundingClientRect();
            const scrollY = window.scrollY;

            popup.style.top = `${rect.bottom + scrollY + 12}px`;
            popup.style.left = `${rect.left + rect.width / 2}px`;
            popup.style.transform = `translateX(-50%)`;

            arrow.style.top = `${rect.bottom + scrollY + 2}px`;
            arrow.style.left = `${rect.left + rect.width / 2 - 10}px`;
        }

        function nextNavbarTourStep() {
            navbarTourIndex++;
            if (navbarTourIndex >= navbarTourSteps.length) {
                document.getElementById('navbarTourPopup').style.display = 'none';
                document.getElementById('navbarTourArrow').style.display = 'none';
                document.getElementById('navbarTourBackdrop').style.display = 'none';
                document.querySelectorAll('.navbar-tour-highlight').forEach(el => el.classList.remove('navbar-tour-highlight'));
                localStorage.setItem('navbarTourCompleted', 'yes');
                return;
            }
            showNavbarTourStep(navbarTourIndex);
        }

        // window.addEventListener('load', () => {
        //     setTimeout(() => {
        //         startNavbarTour();
        //     }, 1000);
        // });
    </script>

    <script>
    document.getElementById('unsubscribe-btn').addEventListener('click', function(e) {
        e.preventDefault();

        Swal.fire({
            title: 'Are you sure?',
            text: "Your subscription will be cancelled immediately.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, unsubscribe'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch("<?php echo e(route('unsubscribe')); ?>", {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    Swal.fire('Unsubscribed!', data.message, 'success')
                        .then(() => window.location.reload());
                })
                .catch(err => {
                    Swal.fire('Error', 'Unable to unsubscribe. Please try again.', 'error');
                });
            }
        });
    });
    </script>

    
    <?php echo $__env->make('components.loader', ['id' => 'globalLoader', 'message' => 'Loading...'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <script>
        // Show loader on page navigation
        document.addEventListener('DOMContentLoaded', function() {
            // Hide loader when page is fully loaded
            hideLoader('globalLoader');
            
            // Show loader when clicking on links (page navigation)
            document.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', function(e) {
                    const href = this.getAttribute('href');
                    const target = this.getAttribute('target');
                    
                    // Check if it's a download link (PDF or any file)
                    const isDownload = this.hasAttribute('download') || 
                                     href?.includes('/download') || 
                                     href?.includes('.pdf') ||
                                     href?.includes('/pdf/');
                    
                    // Only show loader for internal navigation (not external links, not new tabs, not anchors, not downloads)
                    if (href && 
                        !href.startsWith('#') && 
                        !href.startsWith('javascript:') && 
                        !href.startsWith('mailto:') && 
                        !href.startsWith('tel:') &&
                        target !== '_blank' &&
                        !this.hasAttribute('data-no-loader') &&
                        !isDownload) {
                        
                        showLoader('globalLoader', 'Loading page...');
                    }
                });
            });

            // Show loader when submitting forms (unless specified not to)
            document.querySelectorAll('form').forEach(form => {
                form.addEventListener('submit', function(e) {
                    if (!this.hasAttribute('data-no-loader')) {
                        showLoader('globalLoader', 'Processing...');
                    }
                });
            });

            // Hide loader if user navigates back
            window.addEventListener('pageshow', function(event) {
                if (event.persisted) {
                    hideLoader('globalLoader');
                }
            });

            // Fallback: Hide loader after 10 seconds (in case something goes wrong)
            setTimeout(() => {
                hideLoader('globalLoader');
            }, 10000);
        });

        // Show loader immediately when page starts loading
        if (document.readyState === 'loading') {
            showLoader('globalLoader', 'Loading page...');
        }
    </script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\public_html\resources\views/layouts/app.blade.php ENDPATH**/ ?>