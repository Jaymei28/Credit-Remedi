<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<style>
    /* Progress Bar Styles */
    .progress-custom {
        height: 8px;
        border-radius: 10px;
        background: var(--bg-tertiary);
        overflow: hidden;
    }

    .progress-bar-custom {
        background: var(--gradient-primary);
        height: 100%;
        border-radius: 10px;
        transition: width 1s ease-in-out;
    }

    /* Activity Feed Styles */
    .activity-item {
        position: relative;
        padding-left: 2.5rem;
        padding-bottom: 1.5rem;
        border-left: 2px solid var(--border-color);
    }

    .activity-item:last-child {
        border-left-color: transparent;
        padding-bottom: 0;
    }

    .activity-icon {
        position: absolute;
        left: -0.75rem;
        top: 0;
        width: 2rem;
        height: 2rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.875rem;
        background: var(--bg-primary);
        border: 2px solid var(--border-color);
    }

    /* Checklist Styles */
    .checklist-item {
        padding: 0.75rem 1rem;
        border-radius: var(--border-radius-md);
        transition: all var(--transition-base);
        cursor: pointer;
    }

    .checklist-item:hover {
        background: var(--bg-secondary);
    }

    .checklist-item.completed {
        opacity: 0.6;
    }

    .checklist-item.completed .btn {
        opacity: 1 !important;
    }

    .checklist-checkbox {
        width: 1.25rem;
        height: 1.25rem;
        border-radius: 50%;
        border: 2px solid var(--border-color);
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all var(--transition-base);
    }

    .checklist-item.completed .checklist-checkbox {
        background: var(--gradient-success);
        border-color: transparent;
    }

    /* Stats Card Animation */
    @keyframes countUp {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .stat-number {
        animation: countUp 0.5s ease-out;
    }

    /* Mobile Responsive - Smaller Cards */
    @media (max-width: 768px) {
        /* Reduce card padding */
        .card-body {
            padding: 1rem !important;
        }

        /* Smaller icons */
        .card-body i.fs-3 {
            font-size: 1.5rem !important;
            margin-bottom: 0.5rem !important;
        }

        /* Smaller stat numbers */
        .stat-number {
            font-size: 1.75rem !important;
        }

        /* Smaller card titles */
        .card-title.text-uppercase.small {
            font-size: 0.7rem !important;
        }

        /* Smaller text below stats */
        .card-body small {
            font-size: 0.75rem !important;
        }

        /* Reduce gap between stat cards */
        .row.g-3 {
            gap: 0.75rem !important;
        }

        /* Make stat cards more compact */
        .col-md-3.col-sm-6 .card {
            margin-bottom: 0;
        }

        /* Smaller buttons in checklist */
        .checklist-item .btn {
            padding: 0.4rem 0.8rem !important;
            font-size: 0.8rem !important;
            white-space: nowrap !important;
            min-width: auto !important;
        }

        /* Smaller checklist text */
        .checklist-item p {
            font-size: 0.85rem !important;
            margin-bottom: 0.25rem !important;
        }

        /* Smaller checklist small text */
        .checklist-item small {
            font-size: 0.75rem !important;
        }

        /* Smaller checklist checkbox */
        .checklist-checkbox {
            width: 1rem !important;
            height: 1rem !important;
            min-width: 1rem !important;
        }

        /* Adjust checklist item spacing */
        .checklist-item {
            padding: 0.5rem 0.75rem !important;
        }

        /* Smaller quick action buttons */
        .btn-md {
            padding: 0.5rem 1rem !important;
            font-size: 0.85rem !important;
        }
    }
</style>

<div class="container px-2 px-md-3 mb-5">

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center fw-semibold auto-dismiss-alert" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="alert alert-info alert-dismissible fade show text-center fw-semibold auto-dismiss-alert" role="alert">
            <?php echo e(session('info')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show text-center fw-semibold auto-dismiss-alert" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    
    <div class="row mb-4">
        <div class="col-12">
            <div class="card card-gradient shadow-strong">
                <div class="card-body p-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h3 class="text-white mb-2">
                                <?php
                                    $hour = date('H');
                                    $greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
                                ?>
                                <?php echo e($greeting); ?>, <?php echo e(Auth::user()->name); ?>! 👋
                            </h3>
                            <p class="text-white mb-0 opacity-90">
                                Here's your credit journey progress. You're doing great!
                            </p>
                        </div>
                        <div class="col-md-4 text-md-end mt-3 mt-md-0">
                            <img src="<?php echo e(asset('4-removebg-preview.png')); ?>" alt="Credit Remedi Logo" style="max-width: 120px; height: auto;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if(auth()->user()->role === 'admin'): ?>
        
        <div class="row mb-4 g-3">
            <!-- Metric Cards -->
            <div class="col-lg-8">
                <div class="row g-3">
                    <div class="col-md-6 col-lg-6">
                        <div class="card card-border-primary shadow-soft hover-lift">
                            <div class="card-body text-center">
                                <i class="bi bi-people-fill text-primary fs-3 mb-2"></i>
                                <h6 class="card-title text-uppercase small mb-1 text-muted">Total Users</h6>
                                <h2 class="fw-bold mb-0 gradient-text stat-number"><?php echo e($userCount); ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6">
                        <div class="card card-border-info shadow-soft hover-lift">
                            <div class="card-body text-center">
                                <i class="bi bi-folder-check text-info fs-3 mb-2"></i>
                                <h6 class="card-title text-uppercase small mb-1 text-muted">Total Disputes</h6>
                                <h2 class="fw-bold mb-0 gradient-text stat-number"><?php echo e($disputesFiled); ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6">
                        <div class="card card-border-warning shadow-soft hover-lift">
                            <div class="card-body text-center">
                                <i class="bi bi-hourglass-split text-warning fs-3 mb-2"></i>
                                <h6 class="card-title text-uppercase small mb-1 text-muted">Pending Letters</h6>
                                <h2 class="fw-bold mb-0 stat-number"><?php echo e($pendingDisputes); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Top Users Table -->
            <div class="col-lg-4">
                <div class="card shadow-soft h-100 hover-lift">
                    <div class="card-header">
                        <h6 class="mb-0">👥 Top Users by Letters Filed</h6>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-sm table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="text-start">User</th>
                                    <th class="text-center">Letters</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $topUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="text-start"><?php echo e($user->name); ?></td>
                                        <td class="text-center fw-semibold"><?php echo e($user->letter_count); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="2" class="text-center text-muted">No data.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    <?php else: ?>
        
        
        
        <div class="row mb-4 g-3">
            <div class="col-md-3 col-sm-6">
                <div class="card card-border-primary shadow-soft hover-lift">
                    <div class="card-body text-center">
                        <i class="bi bi-file-earmark-text text-primary fs-3 mb-2"></i>
                        <h6 class="text-uppercase small mb-1 text-muted">Disputes Filed</h6>
                        <h2 class="fw-bold mb-0 gradient-text stat-number"><?php echo e($totalDisputes); ?></h2>
                        <small class="text-muted"><?php echo e($totalDisputes > 0 ? 'Keep going!' : 'Start your journey'); ?></small>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card card-border-success shadow-soft hover-lift">
                    <div class="card-body text-center">
                        <i class="bi bi-check-circle text-success fs-3 mb-2"></i>
                        <h6 class="text-uppercase small mb-1 text-muted">Items Removed</h6>
                        <h2 class="fw-bold mb-0 stat-number"><?php echo e($itemsRemoved); ?></h2>
                        <small class="text-muted"><?php echo e($itemsRemoved > 0 ? 'Great progress!' : 'Coming soon'); ?></small>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card card-border-warning shadow-soft hover-lift">
                    <div class="card-body text-center">
                        <i class="bi bi-clock-history text-warning fs-3 mb-2"></i>
                        <h6 class="text-uppercase small mb-1 text-muted">Pending</h6>
                        <h2 class="fw-bold mb-0 stat-number"><?php echo e($userPendingDisputes); ?></h2>
                        <small class="text-muted"><?php echo e($userPendingDisputes > 0 ? 'In progress' : 'All clear'); ?></small>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="card card-border-info shadow-soft hover-lift">
                    <div class="card-body text-center">
                        <i class="bi bi-graph-up-arrow text-info fs-3 mb-2"></i>
                        <h6 class="text-uppercase small mb-1 text-muted">Credit Score</h6>
                        <?php if($averageCreditScore): ?>
                            <h2 class="fw-bold mb-0 stat-number"><?php echo e($averageCreditScore); ?></h2>
                            <small class="text-success">Average Score</small>
                        <?php else: ?>
                            <h2 class="fw-bold mb-0 stat-number"><?php echo e($creditScoreTrend >= 0 ? '+' : ''); ?><?php echo e($creditScoreTrend); ?></h2>
                            <small class="<?php echo e($creditScoreTrend > 0 ? 'text-success' : 'text-muted'); ?>"><?php echo e($creditScoreTrend > 0 ? '↑ Trending up' : 'Track your progress'); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            
            <div class="col-lg-6">
                <div class="card shadow-soft h-100">
                    <div class="card-header">
                        <h5 class="mb-0">🔔 Recent Activity</h5>
                    </div>
                    <div class="card-body">
                        <div class="activity-feed">
                            <?php $__empty_1 = true; $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="activity-item">
                                    <?php
                                        $iconClass = 'bg-primary';
                                        $icon = 'file-earmark-plus';
                                        $title = 'Dispute filed';
                                        
                                        if ($activity->posted_1) {
                                            $iconClass = 'bg-success';
                                            $icon = 'check-circle';
                                            $title = 'Dispute completed';
                                        } elseif ($activity->sent) {
                                            $iconClass = 'bg-info';
                                            $icon = 'send';
                                            $title = 'Dispute sent';
                                        }
                                    ?>
                                    <div class="activity-icon <?php echo e($iconClass); ?> text-white">
                                        <i class="bi bi-<?php echo e($icon); ?>"></i>
                                    </div>
                                    <div>
                                        <p class="mb-1 fw-semibold"><?php echo e($title); ?></p>
                                        <p class="mb-0 small text-muted">
                                            <?php echo e($activity->credit_item_type ?? 'Dispute'); ?> - <?php echo e($activity->creditor_name ?? 'Creditor'); ?>

                                        </p>
                                        <small class="text-muted"><?php echo e($activity->updated_at->diffForHumans()); ?></small>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center py-4">
                                    <i class="bi bi-inbox fs-1 text-muted mb-2"></i>
                                    <p class="text-muted mb-0">No activity yet</p>
                                    <small class="text-muted">File your first dispute to get started!</small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <a href="<?php echo e(route('disputes.index')); ?>" class="btn btn-sm btn-outline-primary w-100">View All Activity</a>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-6">
                <div class="card shadow-soft h-100">
                    <div class="card-header">
                        <h5 class="mb-0">✅ Getting Started Checklist</h5>
                        <small class="text-muted">Complete these steps to maximize your results</small>
                    </div>
                    <div class="card-body">
                        <div class="checklist">
                            <div class="checklist-item <?php echo e($onboardingSteps['account_created'] ? 'completed' : ''); ?> mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="checklist-checkbox me-3">
                                        <?php if($onboardingSteps['account_created']): ?>
                                            <i class="bi bi-check text-white"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <p class="mb-0 fw-semibold">Create your account</p>
                                        <small class="text-muted">Welcome to Credit Remedi!</small>
                                    </div>
                                </div>
                            </div>
                            <div class="checklist-item <?php echo e($onboardingSteps['report_uploaded'] ? 'completed' : ''); ?> mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="checklist-checkbox me-3">
                                        <?php if($onboardingSteps['report_uploaded']): ?>
                                            <i class="bi bi-check text-white"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <p class="mb-0 fw-semibold">Upload your credit report</p>
                                        <small class="text-muted"><?php echo e($onboardingSteps['report_uploaded'] ? 'Great! We can now analyze it' : 'Add your credit report to vault'); ?></small>
                                    </div>
                                    <?php if(!$onboardingSteps['report_uploaded']): ?>
                                        <a href="<?php echo e(route('credit-vault')); ?>" class="btn btn-sm btn-outline-primary">Upload</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="checklist-item <?php echo e($onboardingSteps['ai_analysis_run'] ? 'completed' : ''); ?> mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="checklist-checkbox me-3">
                                        <?php if($onboardingSteps['ai_analysis_run']): ?>
                                            <i class="bi bi-check text-white"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1" style="<?php echo e($onboardingSteps['ai_analysis_run'] ? 'opacity: 1;' : ''); ?>">
                                        <p class="mb-0 fw-semibold">Run AI analysis</p>
                                        <?php
                                            $hasPaidPlan = in_array(auth()->user()->plan_type, ['starter', 'standard', 'pro', 'premium']) || auth()->user()->role === 'admin';
                                        ?>
                                        <?php if($hasPaidPlan): ?>
                                            <small class="text-muted">Let AI identify disputable items</small>
                                        <?php else: ?>
                                            <small class="text-warning">⭐ Paid feature - <a href="<?php echo e(route('plans')); ?>" class="text-warning fw-bold">Upgrade to unlock</a></small>
                                        <?php endif; ?>
                                    </div>
                                    <?php if($hasPaidPlan): ?>
                                        <?php if(!$onboardingSteps['ai_analysis_run']): ?>
                                            <form action="<?php echo e(route('ai-analysis.run')); ?>" method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-sm btn-gradient-primary">Start</button>
                                            </form>
                                        <?php else: ?>
                                            <?php
                                                $latestReport = \App\Models\CreditReport::where('user_id', auth()->id())
                                                    ->latest()
                                                    ->first();
                                            ?>
                                            <?php if($latestReport): ?>
                                                <a href="<?php echo e(route('ai-analysis.results', ['id' => $latestReport->id])); ?>" 
                                                   class="btn btn-success text-white fw-bold shadow-sm" 
                                                   style="opacity: 1 !important; filter: none !important;">
                                                    <i class="bi bi-eye me-1"></i>View Results
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('plans')); ?>" class="btn btn-sm btn-warning">Upgrade</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="checklist-item <?php echo e($onboardingSteps['first_dispute_filed'] ? 'completed' : ''); ?> mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="checklist-checkbox me-3">
                                        <?php if($onboardingSteps['first_dispute_filed']): ?>
                                            <i class="bi bi-check text-white"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <p class="mb-0 fw-semibold">File your first dispute</p>
                                        <small class="text-muted"><?php echo e($onboardingSteps['first_dispute_filed'] ? 'Great job! Keep going' : 'Take action on negative items'); ?></small>
                                    </div>
                                    <?php if(!$onboardingSteps['first_dispute_filed']): ?>
                                        <a href="<?php echo e(route('disputes.index')); ?>" class="btn btn-sm btn-outline-primary">Go</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="checklist-item <?php echo e($onboardingSteps['resources_explored'] ? 'completed' : ''); ?> mb-2">
                                <div class="d-flex align-items-center">
                                    <div class="checklist-checkbox me-3">
                                        <?php if($onboardingSteps['resources_explored']): ?>
                                            <i class="bi bi-check text-white"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <p class="mb-0 fw-semibold">Explore resources</p>
                                        <small class="text-muted">Learn credit repair strategies</small>
                                    </div>
                                    <?php if(!$onboardingSteps['resources_explored']): ?>
                                        <a href="<?php echo e(route('resource-center')); ?>" class="btn btn-sm btn-outline-primary">Learn</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer bg-transparent">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="small text-muted"><?php echo e($completedSteps); ?> of <?php echo e($totalSteps); ?> completed</span>
                            <span class="small fw-semibold text-primary"><?php echo e($onboardingProgress); ?>% Complete</span>
                        </div>
                        <div class="progress-custom mt-2">
                            <div class="progress-bar-custom" style="width: <?php echo e($onboardingProgress); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row mt-4">
            <div class="col-12">
                <?php echo $__env->make('components.credit-report-widget', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>

        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card shadow-soft">
                    <div class="card-header">
                        <h5 class="mb-0">⚡ Quick Actions</h5>
                    </div>
                    <div class="card-body">
                        <?php if(in_array(auth()->user()->plan_type, ['pro', 'premium']) || auth()->user()->role === 'admin'): ?>
                            
                            <div class="row g-3">
                                <div class="col-lg col-md-4 col-sm-6">
                                    <a href="<?php echo e(route('disputes.index')); ?>" class="btn btn-gradient-primary btn-md w-100">
                                        <i class="bi bi-folder-check me-2"></i> My Disputes
                                    </a>
                                </div>
                                <?php if(auth()->user()->plan_type === 'premium' || auth()->user()->role === 'admin'): ?>
                                    <div class="col-lg col-md-4 col-sm-6">
                                        <a href="<?php echo e(route('credit-repair-bot')); ?>" class="btn btn-md w-100 fw-semibold shadow-soft border-0" style="background: linear-gradient(135deg, #00C8C8 0%, #00A0A0 100%); color: #000;">
                                            <i class="bi bi-robot me-2"></i> AI Chat
                                        </a>
                                    </div>
                                <?php endif; ?>
                                <div class="col-lg col-md-4 col-sm-6">
                                    <a href="<?php echo e(route('fundability.index')); ?>" class="btn btn-md w-100 fw-semibold shadow-soft border-0" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: #fff;">
                                        <i class="bi bi-graph-up-arrow me-2"></i> Fundability
                                    </a>
                                </div>
                                <div class="col-lg col-md-4 col-sm-6">
                                    <a href="<?php echo e(route('credit-vault')); ?>" class="btn btn-gradient-info btn-md w-100">
                                        <i class="bi bi-list-check me-2"></i> Credit Vault
                                    </a>
                                </div>
                                <div class="col-lg col-md-4 col-sm-6">
                                    <a href="https://www.skool.com/credit-remedy-academy-5068/about?ref=cd2596c36ce54883a4a1a876af63413a" target="_blank" class="btn btn-md w-100 fw-semibold shadow-soft border-0" style="background: linear-gradient(135deg, #9333EA 0%, #7C3AED 100%); color: #fff;">
                                        <i class="bi bi-people-fill me-2"></i> Community
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            
                            <div class="row g-3 justify-content-center">
                                <div class="col-md-5 col-lg-4">
                                    <a href="<?php echo e(route('disputes.index')); ?>" class="btn btn-gradient-primary btn-md w-100">
                                        <i class="bi bi-folder-check me-2"></i> My Disputes
                                    </a>
                                </div>
                                <div class="col-md-5 col-lg-4">
                                    <a href="<?php echo e(route('credit-vault')); ?>" class="btn btn-gradient-info btn-md w-100">
                                        <i class="bi bi-list-check me-2"></i> Credit Vault
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Auto-dismiss flash notifications after 1 second
    document.addEventListener('DOMContentLoaded', () => {
        const alerts = document.querySelectorAll('.auto-dismiss-alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }, 5000); // 5 seconds
        });

        // Animate progress bars on load
        const progressBars = document.querySelectorAll('.progress-bar-custom');
        progressBars.forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0';
            setTimeout(() => {
                bar.style.width = width;
            }, 100);
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\public_html\resources\views/dashboard.blade.php ENDPATH**/ ?>