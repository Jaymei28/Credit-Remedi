

<?php $__env->startSection('title', 'Fundability Score & Lender Matching'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .fundability-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 20px;
        padding: 3rem;
        color: white;
        margin-bottom: 2rem;
        position: relative;
        overflow: hidden;
    }

    .fundability-hero::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -10%;
        width: 400px;
        height: 400px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
    }

    .score-circle {
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background: white;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        margin: 0 auto 2rem;
    }

    .score-number {
        font-size: 4rem;
        font-weight: 800;
        line-height: 1;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
    }

    .score-grade {
        font-size: 1.5rem;
        font-weight: 700;
        color: #6b7280;
        margin-top: 0.5rem;
    }

    .factor-card {
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
    }

    .factor-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
    }

    .factor-progress {
        height: 8px;
        background: var(--bg-tertiary);
        border-radius: 10px;
        overflow: hidden;
        margin-top: 0.5rem;
    }

    .factor-progress-bar {
        height: 100%;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
        transition: width 1s ease;
    }

    .recommendation-card {
        background: var(--bg-secondary);
        border: 1px solid var(--border-color);
        border-left: 4px solid #3b82f6;
        border-radius: 8px;
        padding: 1.25rem;
        margin-bottom: 1rem;
    }

    .recommendation-card.high-priority {
        background: var(--bg-secondary);
        border-left-color: #f59e0b;
    }

    .strength-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.9rem;
        font-weight: 600;
        margin: 0.25rem;
        box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
    }

    .weakness-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.9rem;
        font-weight: 600;
        margin: 0.25rem;
        box-shadow: 0 2px 8px rgba(239, 68, 68, 0.3);
    }

    .cta-button {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
        padding: 1rem 2rem;
        border-radius: 12px;
        font-size: 1.1rem;
        font-weight: 700;
        border: none;
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.4);
        transition: all 0.3s ease;
        text-decoration: none;
        display: inline-block;
    }

    .cta-button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(16, 185, 129, 0.5);
        color: white;
    }

    .empty-state {
        text-align: center;
        padding: 4rem 2rem;
    }

    .empty-state-icon {
        font-size: 5rem;
        color: #d1d5db;
        margin-bottom: 1rem;
    }
</style>

<div class="container px-3 mb-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(!$hasScore): ?>
        
        <div class="fundability-hero">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="mb-3">🎯 Fundability Score & Lender Matching</h1>
                    <p class="lead mb-4">
                        Discover your funding potential and get matched with lenders who are most likely to approve you.
                    </p>
                    <ul class="list-unstyled mb-4">
                        <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i> Comprehensive fundability analysis</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i> Personalized lender recommendations</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i> Estimated approval odds & rates</li>
                        <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i> Actionable improvement tips</li>
                    </ul>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="bi bi-graph-up-arrow" style="font-size: 8rem; opacity: 0.3;"></i>
                </div>
            </div>
        </div>

        <div class="card shadow-soft">
            <div class="card-body p-5">
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <i class="bi bi-calculator"></i>
                    </div>
                    <h3 class="mb-3">Ready to Calculate Your Fundability Score?</h3>
                    <p class="text-muted mb-4">
                        We'll analyze your credit profile and match you with lenders based on your unique financial situation.
                    </p>
                    
                    <form action="<?php echo e(route('fundability.calculate')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="cta-button">
                            <i class="bi bi-calculator me-2"></i> Calculate My Score
                        </button>
                    </form>

                    <div class="mt-4">
                        <small class="text-muted">
                            <i class="bi bi-info-circle me-1"></i>
                            This analysis uses your IdentityIQ report data and dispute history
                        </small>
                    </div>
                </div>
            </div>
        </div>

    <?php else: ?>
        
        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-soft">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h2 class="mb-1">Your Fundability Score</h2>
                                <p class="text-muted mb-0">
                                    <i class="bi bi-clock-history me-1"></i>
                                    Last updated <?php echo e($fundabilityScore->updated_at->diffForHumans()); ?>

                                </p>
                            </div>
                            <form action="<?php echo e(route('fundability.calculate')); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-primary">
                                    <i class="bi bi-arrow-clockwise me-1"></i> Recalculate
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-4">
            
            <div class="col-lg-4">
                <div class="card shadow-soft h-100">
                    <div class="card-body text-center p-4">
                        <div class="score-circle">
                            <div class="score-number"><?php echo e($fundabilityScore->score); ?></div>
                            <div class="score-grade">Grade <?php echo e($fundabilityScore->grade); ?></div>
                        </div>
                        <h5 class="mb-3">Fundability Score</h5>
                        <p class="text-muted">
                            <?php if($fundabilityScore->score >= 80): ?>
                                Excellent! You have strong funding potential.
                            <?php elseif($fundabilityScore->score >= 70): ?>
                                Good! You're in a solid position for approval.
                            <?php elseif($fundabilityScore->score >= 60): ?>
                                Fair. Some improvements could boost your odds.
                            <?php elseif($fundabilityScore->score >= 50): ?>
                                Needs work. Focus on the recommendations below.
                            <?php else: ?>
                                Significant improvement needed. Start with credit repair.
                            <?php endif; ?>
                        </p>
                        <a href="<?php echo e(route('fundability.results')); ?>" class="btn btn-gradient-primary w-100 mt-3">
                            <i class="bi bi-bank me-2"></i> View Lender Matches
                        </a>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-8">
                <div class="card shadow-soft h-100">
                    <div class="card-body p-4">
                        <h5 class="mb-3"><i class="bi bi-trophy me-2 text-success"></i> Your Strengths</h5>
                        <div class="mb-4">
                            <?php if(!empty($fundabilityScore->strengths)): ?>
                                <?php $__currentLoopData = $fundabilityScore->strengths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strength): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="strength-badge">
                                        <i class="bi bi-check-circle-fill"></i> <?php echo e($strength); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-muted">Keep working on your credit to build strengths!</p>
                            <?php endif; ?>
                        </div>

                        <h5 class="mb-3"><i class="bi bi-exclamation-triangle me-2 text-warning"></i> Areas to Improve</h5>
                        <div>
                            <?php if(!empty($fundabilityScore->weaknesses)): ?>
                                <?php $__currentLoopData = $fundabilityScore->weaknesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weakness): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="weakness-badge">
                                        <i class="bi bi-x-circle-fill"></i> <?php echo e($weakness); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-success">Great! No major weaknesses detected.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-soft">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-bar-chart me-2"></i> Score Breakdown</h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="row g-3">
                            <?php if(!empty($fundabilityScore->factors)): ?>
                                <?php $__currentLoopData = $fundabilityScore->factors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $factor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6">
                                        <div class="factor-card">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <h6 class="mb-0"><?php echo e(ucwords(str_replace('_', ' ', $key))); ?></h6>
                                                <span class="badge bg-primary"><?php echo e($factor['points']); ?>/<?php echo e($factor['max_points']); ?> pts</span>
                                            </div>
                                            <div class="factor-progress">
                                                <div class="factor-progress-bar" style="width: <?php echo e($factor['percentage']); ?>%"></div>
                                            </div>
                                            <small class="text-muted mt-2 d-block">
                                                <?php if(isset($factor['value'])): ?>
                                                    Score: <?php echo e($factor['value']); ?>

                                                <?php elseif(isset($factor['count'])): ?>
                                                    Count: <?php echo e($factor['count']); ?>

                                                <?php elseif(isset($factor['total_accounts'])): ?>
                                                    <?php echo e($factor['total_accounts']); ?> total, <?php echo e($factor['open_accounts']); ?> open
                                                <?php elseif(isset($factor['completed'])): ?>
                                                    <?php echo e($factor['completed']); ?> completed disputes
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="row">
            <div class="col-12">
                <div class="card shadow-soft">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-lightbulb me-2"></i> Personalized Recommendations</h5>
                    </div>
                    <div class="card-body p-4">
                        <?php if(!empty($fundabilityScore->recommendations)): ?>
                            <?php $__currentLoopData = $fundabilityScore->recommendations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="recommendation-card <?php echo e($recommendation['priority'] === 'high' ? 'high-priority' : ''); ?>">
                                    <div class="d-flex align-items-start justify-content-between">
                                        <div class="d-flex align-items-start flex-grow-1">
                                            <div class="me-3">
                                                <i class="bi bi-<?php echo e($recommendation['icon']); ?> fs-4"></i>
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?php echo e($recommendation['title']); ?></h6>
                                                <p class="mb-0 small"><?php echo e($recommendation['description']); ?></p>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center gap-2 ms-3">
                                            <?php if($recommendation['priority'] === 'high'): ?>
                                                <span class="badge bg-warning text-dark">High Priority</span>
                                            <?php endif; ?>
                                            <?php if(isset($recommendation['action_url'])): ?>
                                                <a href="<?php echo e($recommendation['action_url']); ?>" class="btn btn-sm btn-primary">
                                                    <i class="bi bi-arrow-right-circle me-1"></i><?php echo e($recommendation['action_text'] ?? 'Learn More'); ?>

                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <p class="text-muted mb-0">No specific recommendations at this time. Keep up the good work!</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // Animate progress bars on load
    document.addEventListener('DOMContentLoaded', () => {
        const progressBars = document.querySelectorAll('.factor-progress-bar');
        progressBars.forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0';
            setTimeout(() => {
                bar.style.width = width;
            }, 100);
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\public_html\resources\views/fundability/index.blade.php ENDPATH**/ ?>