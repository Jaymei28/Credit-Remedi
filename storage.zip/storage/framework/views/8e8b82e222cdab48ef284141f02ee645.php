<style>
    /* Credit Report Widget Dark Mode Support */
    .credit-score-card {
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        transition: background 0.3s ease;
    }
    
    [data-theme="dark"] .credit-score-card {
        background: linear-gradient(135deg, #1e3a5f 0%, #2d4a6f 100%);
        border-color: #3b82f6 !important;
    }
    
    [data-theme="dark"] .alert-info {
        background: #1e3a5f !important;
        border-color: #3b82f6 !important;
        color: #93c5fd !important;
    }
    
    [data-theme="dark"] .alert-info .alert-link {
        color: #93c5fd !important;
    }
</style>

<?php if(isset($latestReport) && $latestReport): ?>
<div class="card shadow-sm mb-4" style="border-left: 4px solid #3b82f6;">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="card-title mb-0">
                <i class="bi bi-file-earmark-bar-graph text-primary"></i>
                Your Credit Report Summary
            </h5>
            <small class="text-muted">Imported: <?php echo e($latestReport->created_at->format('M d, Y')); ?></small>
        </div>

        <?php if(isset($creditScores) && $creditScores->count() > 0): ?>
        <div class="row mb-3">
            <div class="col-12 mb-2">
                <h6 class="text-muted mb-0"><strong>Credit Scores:</strong></h6>
            </div>
            <?php $__currentLoopData = $creditScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-2">
                <div class="p-3 rounded credit-score-card" style="border: 1px solid #3b82f6;">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <small class="text-muted d-block" style="font-size: 0.75rem;"><?php echo e($score->bureau); ?></small>
                            <h4 class="mb-0 fw-bold
                                <?php if(in_array($score->lender_rank, ['Excellent', 'Good'])): ?> text-success
                                <?php elseif($score->lender_rank == 'Fair'): ?> text-warning
                                <?php else: ?> text-danger
                                <?php endif; ?>
                            " style="font-size: 2rem;"><?php echo e($score->score); ?></h4>
                        </div>
                        <span class="badge 
                            <?php if(in_array($score->lender_rank, ['Excellent', 'Good'])): ?> bg-success
                            <?php elseif($score->lender_rank == 'Fair'): ?> bg-warning
                            <?php else: ?> bg-danger
                            <?php endif; ?>
                        " style="font-size: 0.7rem;"><?php echo e($score->lender_rank); ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if(isset($accountsCount) && $accountsCount > 0): ?>
        <div class="alert alert-info mb-3" style="background: #f0f9ff; border-color: #3b82f6; color: #1e40af;">
            <i class="bi bi-info-circle"></i>
            <strong><?php echo e($accountsCount); ?> account<?php echo e($accountsCount > 1 ? 's' : ''); ?></strong> found in your credit report.
            <a href="<?php echo e(route('identityiq.report.show', $latestReport->id)); ?>" class="alert-link" style="color: #1e40af; text-decoration: underline;">View details →</a>
        </div>
        <?php endif; ?>

        <div class="d-grid gap-2">
            <a href="<?php echo e(route('credit-repair-bot')); ?>" class="btn btn-primary">
                <i class="bi bi-robot"></i> Generate Dispute Letters with AI
            </a>
            <a href="<?php echo e(route('identityiq.import')); ?>" class="btn btn-outline-secondary btn-sm">
                <i class="bi bi-upload"></i> Upload New Report
            </a>
        </div>
    </div>
</div>
<?php else: ?>
<div class="card shadow-sm mb-4" style="border-left: 4px solid #f59e0b;">
    <div class="card-body">
        <h5 class="card-title">
            <i class="bi bi-exclamation-triangle text-warning"></i>
            No Credit Report Found
        </h5>
        <p class="text-muted mb-3">Upload your IdentityIQ credit report to get started with automated dispute letter generation.</p>
        <a href="<?php echo e(route('identityiq.import')); ?>" class="btn btn-warning">
            <i class="bi bi-upload"></i> Upload Your First Report
        </a>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\public_html\resources\views/components/credit-report-widget.blade.php ENDPATH**/ ?>