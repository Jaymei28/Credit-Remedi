<table id="disputesTable" class="table table-hover align-middle">
    <thead>
        <tr>
            <th style="width: 120px;">Date</th>
            <th>Subject</th>
            <?php if(auth()->user()->role === 'admin'): ?>
                <th style="width: 150px;">User</th>
            <?php endif; ?>
            <th style="width: 180px;">Creditor</th>
            <th style="width: 150px;">Status</th>
            <th style="width: 120px;">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $disputes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dispute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $status = $dispute->posted_1 ? 'approved' : 'pending';
                $statusLabel = $dispute->posted_1 ? 'Posted' : 'Pending';
                $statusIcon = $dispute->posted_1 ? '✅' : '⏳';
            ?>
            <tr onclick="window.location='<?php echo e(route('disputes.show', $dispute->id)); ?>'" style="cursor: pointer;">
                <td data-label="Date" data-order="<?php echo e($dispute->created_at->timestamp); ?>">
                    <small class="text-muted"><?php echo e($dispute->created_at->format('M d, Y')); ?></small>
                </td>
                <td data-label="Subject">
                    <strong><?php echo e(\Illuminate\Support\Str::of($dispute->letter_content)->after('Subject:')->before("\n")->trim()); ?></strong>
                </td>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <td data-label="User"><?php echo e($dispute->user->name ?? 'N/A'); ?></td>
                <?php endif; ?>
                <td data-label="Creditor"><?php echo e($dispute->creditor_name ?? 'N/A'); ?></td>
                <td data-label="Status">
                    <span class="status-badge status-<?php echo e($status); ?>">
                        <?php echo e($statusIcon); ?> <?php echo e($statusLabel); ?>

                    </span>
                </td>
                <td data-label="Action">
                    <a href="<?php echo e(route('disputes.show', $dispute->id)); ?>" class="btn btn-sm btn-outline-primary w-100" onclick="event.stopPropagation()">
                        <i class="bi bi-eye"></i> View
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="<?php echo e(auth()->user()->role === 'admin' ? '6' : '5'); ?>" class="text-center py-4">
                    <div class="empty-state">
                        <i class="bi bi-inbox"></i>
                        <p class="mb-0">No disputes found</p>
                    </div>
                </td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<style>
    /* Status Badges in Table */
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.375rem 0.75rem;
        border-radius: var(--border-radius-sm);
        font-size: 0.85rem;
        font-weight: 600;
        white-space: nowrap;
    }

    .status-pending {
        background: rgba(245, 158, 11, 0.1);
        color: #f59e0b;
        border: 1px solid rgba(245, 158, 11, 0.3);
    }

    .status-approved {
        background: rgba(16, 185, 129, 0.1);
        color: #10b981;
        border: 1px solid rgba(16, 185, 129, 0.3);
    }

    .status-denied {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.3);
    }
</style>
<?php /**PATH C:\xampp\htdocs\public_html\resources\views/partials/dispute-table.blade.php ENDPATH**/ ?>