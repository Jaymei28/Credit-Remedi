<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SubscriptionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CreditRepairBotController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\WaitlistController;
use App\Http\Controllers\StripeWebhookController;



Route::post(
    'stripe/webhook',
    [StripeWebhookController::class, 'handleWebhook']
)->name('cashier.webhook');



Route::get('/', fn() => view('home'));

Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login']);



Route::middleware('guest')->group(function () {
    // Forgot password
    Route::get('forgot-password', [ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
    Route::post('forgot-password', [ForgotPasswordController::class, 'sendResetLinkEmail'])->name('password.email');

    // Reset password
    Route::get('reset-password/{token}', [ResetPasswordController::class, 'showResetForm'])->name('password.reset');
    Route::post('reset-password', [ResetPasswordController::class, 'reset'])->name('password.update');
});


Route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth', 'onboarding'])->name('dashboard');


Route::get('/register', [UserController::class, 'showRegisterForm'])->name('register');
Route::post('/register', [UserController::class, 'register'])->name('register.submit');

// IdentityIQ Onboarding Routes (must be after registration)
use App\Http\Controllers\IdentityIQController;

Route::middleware('auth')->group(function () {
    Route::get('/identityiq/onboarding', [IdentityIQController::class, 'showOnboarding'])->name('identityiq.onboarding');
    Route::post('/identityiq/confirm-existing', [IdentityIQController::class, 'confirmExisting'])->name('identityiq.confirm-existing');
    Route::post('/identityiq/upload-initial-report', [IdentityIQController::class, 'uploadInitialReport'])->name('identityiq.upload-initial-report');
    Route::post('/identityiq/skip', [IdentityIQController::class, 'skipOnboarding'])->name('identityiq.skip')->middleware('admin');
});


Route::post('/logout', function (Request $request) {
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect('/login'); // or wherever you want after logout
})->name('logout');

Route::middleware(['auth', 'admin'])->group(function () {
    Route::resource('users', UserController::class);
});



Route::get('/credit-vault', function () {
    return view('credit-vault');
})->name('credit-vault')->middleware(['auth', 'onboarding']);

Route::get('/disputes/filter', [CreditRepairBotController::class, 'filter'])->name('disputes.filter')->middleware(['auth', 'onboarding']);


Route::middleware('auth')->group(function () {
    Route::get('/subscribe', [SubscriptionController::class, 'show']);
    Route::post('/subscribe', [SubscriptionController::class, 'store'])->name('subscribe');
});




Route::middleware(['auth', 'onboarding'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
    Route::put('/profile/update', [ProfileController::class, 'update'])->name('profile.update');
});

// Show the chat interface
Route::get('/credit-repair-bot', [CreditRepairBotController::class, 'showChat'])->name('credit-repair-bot')->middleware(['auth', 'onboarding', 'premium']);

// Handle AJAX chat submission
Route::post('/credit-repair-bot', [CreditRepairBotController::class, 'chat'])->name('credit-repair-bot.send')->middleware(['auth', 'premium']);

// Reset chat session
Route::post('/credit-repair-bot/reset', function () {
    session()->forget('messages');
    return redirect()->route('credit-repair-bot');
})->name('credit-repair-bot.reset')->middleware(['auth', 'premium']);

// Creditor autocomplete API
Route::get('/api/creditors/search', [CreditRepairBotController::class, 'searchCreditors'])->name('api.creditors.search')->middleware(['auth', 'premium']);

Route::get('/my-disputes', [CreditRepairBotController::class, 'index'])->name('disputes.index')->middleware(['auth', 'onboarding']);
Route::get('/my-disputes/{id}', [CreditRepairBotController::class, 'show'])->name('disputes.show')->middleware(['auth', 'onboarding']);
Route::patch('/disputes/{id}/toggle-post', [CreditRepairBotController::class, 'togglePost'])
    ->name('disputes.togglePost')
    ->middleware('auth');


Route::patch('/disputes/{id}/update-letter', [CreditRepairBotController::class, 'updateLetter'])
->name('disputes.updateLetter')
->middleware('auth');


Route::get('/disputes/{id}/download', [CreditRepairBotController::class, 'downloadPdf'])->name('disputes.downloadPdf')->middleware('auth');


Route::post('/disputes/{id}/follow-up', [CreditRepairBotController::class, 'generateFollowUp'])->name('disputes.generateFollowUp')->middleware('auth');

Route::get('/disputes/{id}/download-followup', [CreditRepairBotController::class, 'downloadFollowUpPdf'])->name('disputes.downloadFollowUpPdf')->middleware('auth');

Route::patch('/disputes/{id}/update-sent', [CreditRepairBotController::class, 'updateSent'])->name('disputes.updateSent')->middleware('auth');


Route::get('/resource-center', function () {
    return view('resource-center');
})->name('resource-center')->middleware(['auth', 'onboarding']);

Route::get('/loader-demo', function () {
    return view('loader-demo');
})->name('loader-demo')->middleware('auth');

// Route::post('/credit/analyze', [CreditRepairBotController::class, 'analyze']);
Route::post('/credit/analyze', [CreditRepairBotController::class, 'analyze'])->name('credit.analyze');




Route::get('/waitlist', [WaitlistController::class, 'create'])->name('waitlist.create');
Route::post('/waitlist', [WaitlistController::class, 'store'])->name('waitlist.store');

Route::get('/waitlist-report', [WaitlistController::class, 'report'])->name('admin.waitlist.report')->middleware(['auth', 'admin']);
Route::get('/referrals/{code}', [WaitlistController::class, 'publicReferrals'])->name('waitlist.public.referrals');

Route::get('/plans', function () {
    return view('plans');
})->name('plans');

Route::post('/unsubscribe', [SubscriptionController::class, 'unsubscribe'])->name('unsubscribe');


Route::middleware('auth')->group(function () {
    // Upload form page
    Route::get('/credit-reports/upload', function () {
        return view('credit-reports.upload');
    })->name('credit-reports.uploadPage');

    // Handle upload
    Route::post('/credit-reports/upload', [CreditRepairBotController::class, 'upload'])->name('credit-reports.upload');

    // Show single report
    Route::get('/credit-reports/{id}', [CreditRepairBotController::class, 'showReport'])->name('credit-reports.show');

    // Generate action plan
    Route::post('/credit-reports/{id}/action-plan', [CreditRepairBotController::class, 'generateActionPlan'])->name('credit-reports.actionPlan');
});

// Credit Data API for Dispute Pre-fill
use App\Http\Controllers\CreditDataController;

Route::middleware(['auth'])->group(function () {
    Route::get('/api/credit-data', [CreditDataController::class, 'getCreditData'])->name('api.credit-data');
    Route::get('/api/credit-data/account/{id}', [CreditDataController::class, 'getAccountDetails'])->name('api.credit-data.account');
});

// IdentityIQ Import Routes
use App\Http\Controllers\IdentityIQImportController;

Route::middleware(['auth', 'onboarding'])->group(function () {
    Route::get('/identityiq/import', [IdentityIQImportController::class, 'index'])->name('identityiq.import');
    Route::post('/identityiq/import', [IdentityIQImportController::class, 'import'])->name('identityiq.import.process');
    Route::get('/identityiq/reports/{id}', [IdentityIQImportController::class, 'show'])->name('identityiq.report.show');
    Route::delete('/identityiq/reports/{id}', [IdentityIQImportController::class, 'destroy'])->name('identityiq.report.delete');
});

// AI Analysis Routes
use App\Http\Controllers\AIAnalysisController;

Route::middleware(['auth', 'onboarding'])->group(function () {
    Route::post('/ai-analysis/run', [AIAnalysisController::class, 'analyze'])->name('ai-analysis.run');
    Route::get('/ai-analysis/results/{id}', [AIAnalysisController::class, 'showResults'])->name('ai-analysis.results');
});

// Fundability Score & Lender Matching Routes
use App\Http\Controllers\FundabilityScoreController;

Route::middleware(['auth', 'onboarding', App\Http\Middleware\CheckProAccess::class])->group(function () {
    Route::get('/fundability-score', [FundabilityScoreController::class, 'index'])->name('fundability.index');
    Route::post('/fundability-score/calculate', [FundabilityScoreController::class, 'calculate'])->name('fundability.calculate');
    Route::get('/fundability-score/results', [FundabilityScoreController::class, 'results'])->name('fundability.results');
});


// Credit Builders Routes
use App\Http\Controllers\CreditBuildersController;

Route::middleware(['auth', 'onboarding'])->group(function () {
    Route::get('/credit-builders', [CreditBuildersController::class, 'index'])->name('credit-builders.index');
});

// Admin Routes
use App\Http\Controllers\Admin\BotPromptController;

Route::middleware(['auth'])->prefix('admin')->name('admin.')->group(function () {
    // Bot Prompts Management
    Route::resource('bot-prompts', BotPromptController::class);
    Route::post('bot-prompts/{botPrompt}/toggle', [BotPromptController::class, 'toggle'])->name('bot-prompts.toggle');
    Route::post('bot-prompts-clear-cache', [BotPromptController::class, 'clearCache'])->name('bot-prompts.clear-cache');
});
