@extends('layouts.app')

@section('title', 'Bot Prompts Management')

@section('content')
<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2 class="mb-0">🤖 Bot Prompts Management</h2>
            <p class="text-muted">Manage AI chatbot prompts, templates, and conversation flows</p>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('admin.bot-prompts.create') }}" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>Create New Prompt
            </a>
            <form action="{{ route('admin.bot-prompts.clear-cache') }}" method="POST" class="d-inline">
                @csrf
                <button type="submit" class="btn btn-outline-secondary" onclick="return confirm('Clear all prompt caches?')">
                    <i class="bi bi-arrow-clockwise me-2"></i>Clear Cache
                </button>
            </form>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.bot-prompts.index') }}" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search prompts..." value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select name="category" class="form-select">
                        <option value="">All Categories</option>
                        @foreach($categories as $category)
                            <option value="{{ $category }}" {{ request('category') == $category ? 'selected' : '' }}>
                                {{ ucfirst($category) }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="active" {{ request('status') == 'active' ? 'selected' : '' }}>Active</option>
                        <option value="inactive" {{ request('status') == 'inactive' ? 'selected' : '' }}>Inactive</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-secondary me-2">
                        <i class="bi bi-search"></i> Filter
                    </button>
                    <a href="{{ route('admin.bot-prompts.index') }}" class="btn btn-outline-secondary">
                        <i class="bi bi-x-circle"></i> Clear
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Prompts Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Key</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Order</th>
                            <th>Status</th>
                            <th>Updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($prompts as $prompt)
                            <tr>
                                <td>
                                    <code class="text-primary">{{ $prompt->key }}</code>
                                </td>
                                <td>
                                    <strong>{{ $prompt->name }}</strong>
                                    @if($prompt->description)
                                        <br><small class="text-muted">{{ Str::limit($prompt->description, 60) }}</small>
                                    @endif
                                </td>
                                <td>
                                    <span class="badge bg-{{ $prompt->category == 'system' ? 'primary' : ($prompt->category == 'template' ? 'success' : 'info') }}">
                                        {{ ucfirst($prompt->category) }}
                                    </span>
                                </td>
                                <td>{{ $prompt->order }}</td>
                                <td>
                                    <form action="{{ route('admin.bot-prompts.toggle', $prompt) }}" method="POST" class="d-inline">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-{{ $prompt->active ? 'success' : 'secondary' }}">
                                            <i class="bi bi-{{ $prompt->active ? 'check-circle' : 'x-circle' }}"></i>
                                            {{ $prompt->active ? 'Active' : 'Inactive' }}
                                        </button>
                                    </form>
                                </td>
                                <td>
                                    <small class="text-muted">{{ $prompt->updated_at->diffForHumans() }}</small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="{{ route('admin.bot-prompts.show', $prompt) }}" class="btn btn-outline-info" title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="{{ route('admin.bot-prompts.edit', $prompt) }}" class="btn btn-outline-primary" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form action="{{ route('admin.bot-prompts.destroy', $prompt) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-outline-danger" title="Delete" 
                                                    onclick="return confirm('Are you sure you want to delete this prompt?')">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <i class="bi bi-inbox fs-1 text-muted"></i>
                                    <p class="text-muted mt-2">No prompts found</p>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            {{ $prompts->links() }}
        </div>
    </div>

    <!-- Stats -->
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h3 class="mb-0">{{ $prompts->total() }}</h3>
                    <small class="text-muted">Total Prompts</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h3 class="mb-0 text-success">{{ App\Models\BotPrompt::where('active', true)->count() }}</h3>
                    <small class="text-muted">Active</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h3 class="mb-0 text-primary">{{ App\Models\BotPrompt::where('category', 'system')->count() }}</h3>
                    <small class="text-muted">System Prompts</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h3 class="mb-0 text-info">{{ App\Models\BotPrompt::where('category', 'template')->count() }}</h3>
                    <small class="text-muted">Templates</small>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
