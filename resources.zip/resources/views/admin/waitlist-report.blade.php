@extends('layouts.app')

@section('title', 'Waitlist Report')

@section('content')

<style>
    @media (min-width: 1200px) {
        .container {
            max-width: 1140px;
        }
    }
</style>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Waitlist Report</h2>
    </div>

    @if (session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <table id="waitlistTable" class="table table-bordered table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Challenge</th>
                <th>Usage</th>
                <th>Timeline</th>
                <th>Referrer</th>
                <th>Referrals</th>
                <th>Qualified</th>
                <th>Registered</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($waitlistUsers as $user)
                <tr>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->challenge }}</td>
                    <td>{{ $user->usage }}</td>
                    <td>{{ $user->timeline }}</td>
                    <td>
                        @if($user->referrer)
                            {{ $user->referrer->name }}<br>
                            <small class="text-muted">{{ $user->referrer->email }}</small>
                        @else
                            <span class="text-muted">–</span>
                        @endif
                    </td>
                    <td>{{ $user->referral_count }}</td>
                    <td>
                        @if($user->is_qualified)
                            <span class="badge bg-success">Yes</span>
                        @else
                            <span class="badge bg-secondary">No</span>
                        @endif
                    </td>
                    <td>{{ $user->created_at ? $user->created_at->format('M d, Y') : '—' }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="9" class="text-center text-muted">No waitlist users found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <!-- Pagination -->
    <div class="d-flex justify-content-center">
        {{ $waitlistUsers->links() }}
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const tableId = '#waitlistTable';

        if ($.fn.DataTable.isDataTable(tableId)) {
            $(tableId).DataTable().destroy();
        }

        $(tableId).DataTable({
            pageLength: 10,
            responsive: true,
            order: [[8, 'desc']]
        });
    });
</script>
@endpush

