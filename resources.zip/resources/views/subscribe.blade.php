@extends('layouts.app')

@section('title', 'Subscribe')

@section('content')
<style>
     @media (min-width: 1200px) {
        .container {
            max-width: 1140px; /* slightly less than default xl */
        }
    }
</style>
<div class="container mt-5">
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    @if (session('info'))
        <div class="alert alert-info">
            {{ session('info') }}
        </div>
    @endif

    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-light text-center fw-semibold">
                    🎟️ One-Time Payment to Use Credit Remedi AI
                </div>

                <div class="card-body">
                    @if (session('success'))
                        <div class="alert alert-success text-center">
                            {{ session('success') }}
                        </div>
                    @endif

                    <form action="{{ route('subscribe') }}" method="POST" id="payment-form">
                        @csrf

                        <div class="mb-3">
                            <label for="card-element" class="form-label fw-semibold">
                                💳 Enter your card details
                            </label>
                            <div id="card-element" class="form-control p-3"></div>
                            <div id="card-errors" class="text-danger mt-2 small" role="alert"></div>
                        </div>

                        <button class="btn btn-primary w-100 shadow-sm fw-semibold" id="submit-button">
                            Pay $49 – One Time Pay
                        </button>
                    </form>

                    <div class="mt-4 text-center small text-muted">
                        Secured by Stripe. No recurring charges. Lifetime access guaranteed.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://js.stripe.com/v3/"></script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const stripe = Stripe("{{ env('STRIPE_KEY') }}");
        const elements = stripe.elements();
        const card = elements.create('card');
        card.mount('#card-element');

        const form = document.getElementById('payment-form');
        const submitButton = document.getElementById('submit-button');
        const errorDiv = document.getElementById('card-errors');

        form.addEventListener('submit', async (e) => {
        e.preventDefault();

        Swal.fire({
            title: 'Confirm Payment',
            text: 'You are about to pay $49 for lifetime access to the Credit Remedi AI.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#0d6efd',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Yes, pay $49',
            cancelButtonText: 'Cancel'
        }).then(async (result) => {
            if (result.isConfirmed) {
                submitButton.disabled = true;

                const { paymentMethod, error } = await stripe.createPaymentMethod('card', card);

                if (error) {
                    errorDiv.textContent = error.message;
                    submitButton.disabled = false;
                } else {
                    const hiddenInput = document.createElement('input');
                    hiddenInput.type = 'hidden';
                    hiddenInput.name = 'paymentMethod';
                    hiddenInput.value = paymentMethod.id;
                    form.appendChild(hiddenInput);
                    form.submit();
                }
            }
        });
    });

    });
</script>
@endpush
