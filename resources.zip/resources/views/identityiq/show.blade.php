@extends('layouts.app')

@section('title', 'Credit Report Analysis')

@section('content')
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

    :root {
        /* Light Mode Variables */
        --bg-main: #f3f4f6;
        --bg-card: #ffffff;
        --bg-header: #ffffff; 
        --text-main: #1f2937;
        --text-secondary: #6b7280;
        --border-color: #e5e7eb;
        --ring-track: #e5e7eb;
        --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        --glass-border: rgba(255, 255, 255, 0.5);
    }

    /* Dark Mode Support */
    :root[data-theme="dark"] {
        --bg-main: #111827;
        --bg-card: #1f2937;
        --bg-header: #1f2937;
        --text-main: #f9fafb;
        --text-secondary: #9ca3af;
        --border-color: #374151;
        --ring-track: #374151;
        --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3), 0 2px 4px -1px rgba(0, 0, 0, 0.2);
        --glass-border: rgba(255, 255, 255, 0.05);
    }

    body {
        font-family: 'Inter', sans-serif;
        background-color: var(--bg-main);
        color: var(--text-main);
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .dashboard-container {
        max-width: 1200px;
        margin: 2rem auto;
        padding: 0 1.5rem;
    }

    /* Header */
    .report-header {
        background: var(--bg-header);
        padding: 2rem;
        border-radius: 20px;
        box-shadow: var(--card-shadow);
        margin-bottom: 2.5rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border: 1px solid var(--border-color);
        transition: all 0.3s ease;
    }

    .header-content h1 {
        font-size: 1.875rem;
        font-weight: 800;
        color: var(--text-main);
        margin-bottom: 0.5rem;
    }

    .header-content p {
        color: var(--text-secondary);
        font-size: 0.95rem;
    }

    .back-btn {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        color: var(--text-main);
        padding: 0.75rem 1.5rem;
        border-radius: 12px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
    }

    .back-btn:hover {
        border-color: var(--text-secondary);
        transform: translateY(-2px);
    }

    /* Score Cards Grid */
    .scores-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
        margin-bottom: 3rem;
    }

    .score-card {
        background: var(--bg-card);
        border-radius: 24px;
        padding: 2rem;
        position: relative;
        box-shadow: var(--card-shadow);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        border: 1px solid var(--border-color);
        overflow: hidden;
    }

    .score-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 6px;
        background: linear-gradient(90deg, var(--score-color, #6366f1), #a855f7);
    }

    .score-card:hover {
        transform: translateY(-5px);
    }

    .bureau-logo {
        font-size: 1.25rem;
        font-weight: 700;
        color: var(--text-main);
        margin-bottom: 2rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .bureau-logo i {
        color: #6366f1;
    }

    /* Circular Progress */
    .score-circle-container {
        display: flex;
        justify-content: center;
        margin-bottom: 2rem;
    }

    .score-circle {
        width: 160px;
        height: 160px;
        border-radius: 50%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        position: relative;
        /* Removed background: white to fix z-index masking issue */
        background: transparent; 
        z-index: 10;
    }

    /* Dynamic Ring using Conic Gradient */
    .ring-bg {
        position: absolute;
        top: -10px;
        left: -10px;
        right: -10px;
        bottom: -10px;
        border-radius: 50%;
        z-index: 1; /* Positive z-index */
        background: conic-gradient(var(--score-color) var(--score-percent), var(--ring-track) 0deg);
        transition: all 1s ease-out;
    }

    .ring-mask {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: var(--bg-card); /* Match card background */
        border-radius: 50%;
        z-index: 2; /* Sit on top of ring-bg */
        margin: 10px; /* Thickness of ring */
    }

    .score-value {
        font-size: 3.5rem;
        font-weight: 800;
        color: var(--text-main);
        line-height: 1;
        z-index: 3; /* Top level */
    }

    .score-label {
        font-size: 0.875rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-top: 0.5rem;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        z-index: 3;
    }

    /* Status Colors */
    .status-excellent { --score-color: #10b981; }
    .status-good { --score-color: #3b82f6; }
    .status-fair { --score-color: #f59e0b; }
    .status-poor { --score-color: #f97316; }
    .status-very-poor { --score-color: #ef4444; }

    /* Light Mode Specific Tinted Backgrounds for Cards - Optional, cleaner to keep white/dark in dark mode */
    /* If you want colored backgrounds, use faint rgba values that work on dark too, or scope them */

    .risk-factors {
        background: var(--bg-main);
        border-radius: 12px;
        padding: 1rem;
        margin-top: 1rem;
        border: 1px solid var(--border-color);
    }

    .risk-title {
        color: var(--text-secondary);
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
    }

    .risk-list li {
        color: var(--text-main);
    }

    /* Data Sections */
    .data-section {
        background: var(--bg-card);
        border-radius: 20px;
        padding: 2rem;
        margin-bottom: 2.5rem;
        box-shadow: var(--card-shadow);
        border: 1px solid var(--border-color);
    }

    .section-header {
        border-bottom: 1px solid var(--border-color);
    }

    .section-title {
        color: var(--text-main);
    }

    .section-badge {
        background: var(--bg-main);
        color: var(--text-secondary);
        border: 1px solid var(--border-color);
    }

    /* Tables */
    .custom-table th {
        background: var(--bg-main);
        color: var(--text-secondary);
        border-bottom: 1px solid var(--border-color);
    }

    .custom-table td {
        border-bottom: 1px solid var(--border-color);
        color: var(--text-main);
    }
    
    .custom-table tr:hover td {
        background: var(--bg-main);
    }

    .status-pill {
        border: 1px solid transparent;
    }
    .pill-open { background: rgba(16, 185, 129, 0.1); color: #10b981; border-color: rgba(16, 185, 129, 0.2); }
    .pill-closed { background: rgba(107, 114, 128, 0.1); color: var(--text-secondary); border-color: rgba(107, 114, 128, 0.2); }
    .pill-neg { background: rgba(239, 68, 68, 0.1); color: #ef4444; border-color: rgba(239, 68, 68, 0.2); }

    /* Responsive */
    @media (max-width: 768px) {
        .report-header {
            flex-direction: column;
            gap: 1rem;
            text-align: center;
        }
        .scores-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="dashboard-container">
    <!-- Header -->
    <div class="report-header">
        <div class="header-content">
            <h1>Credit Report Analysis</h1>
            <div>
                <span class="text-sm font-semibold opacity-75 mr-3">{{ $creditReport->original_filename }}</span>
                <span class="text-sm opacity-75"><i class="bi bi-clock"></i> {{ $creditReport->created_at->format('M d, Y') }}</span>
            </div>
        </div>
        <a href="{{ route('identityiq.import') }}" class="back-btn">
            <i class="bi bi-arrow-left"></i> Back to Dashboard
        </a>
    </div>

    <!-- Credit Scores -->
    @if($creditScores->count() > 0)
        <div class="scores-grid">
            @foreach($creditScores as $score)
                @php
                    $statusClass = 'status-very-poor';
                    if($score->score >= 750) $statusClass = 'status-excellent';
                    elseif($score->score >= 700) $statusClass = 'status-good';
                    elseif($score->score >= 650) $statusClass = 'status-fair';
                    elseif($score->score >= 600) $statusClass = 'status-poor';
                    
                    // Cap max visually at 100% (approx 850 score)
                    // (Score - 300) / (850 - 300) * 360 degrees
                    // 550 range
                    $degrees = max(0, min(360, ($score->score - 300) / 550 * 360));
                @endphp

                <div class="score-card {{ $statusClass }}" style="--score-percent: {{ $degrees }}deg;">
                    <div class="bureau-logo">
                        <i class="bi bi-building"></i> {{ $score->bureau }}
                    </div>
                    
                    <div class="score-circle-container">
                        <div class="score-circle">
                            <!-- Conic Gradient Ring -->
                            <div class="ring-bg"></div>
                            <div class="ring-mask"></div>
                            
                            <span class="score-value">{{ $score->score }}</span>
                            <!-- Inline style color to force text match score color even in dark mode -->
                            <span class="score-label" style="color: var(--score-color); background: rgba(var(--score-color), 0.1, 0);">{{ $score->lender_rank }}</span>
                        </div>
                    </div>

                    @if($score->risk_factors && count($score->risk_factors) > 0)
                        <div class="risk-factors">
                            <div class="risk-title">Risk Factors</div>
                            <ul class="risk-list">
                                @foreach(array_slice($score->risk_factors, 0, 2) as $factor)
                                    <li>{{ Str::limit($factor, 60) }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                </div>
            @endforeach
        </div>
    @endif

    <!-- Accounts -->
    @if($accounts->count() > 0)
        <div class="data-section">
            <div class="section-header">
                <div class="section-title">
                    <i class="bi bi-wallet2 text-blue-500"></i>
                    Credit Accounts
                </div>
                <span class="section-badge">{{ $accounts->count() }} Accounts found</span>
            </div>
            
            <div style="overflow-x: auto;">
                <table class="custom-table">
                    <thead>
                        <tr>
                            <th>Creditor</th>
                            <th>Type</th>
                            <th>Status/Balance</th>
                            <th>Limit</th>
                            <th>Bureau</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($accounts as $account)
                        <tr>
                            <td>
                                <div style="font-weight: 600;">{{ $account->creditor_name }}</div>
                                <div style="font-size: 0.8rem; opacity: 0.7;">{{ $account->account_number ?? '****' }}</div>
                            </td>
                            <td>{{ $account->account_type ?? '-' }}</td>
                            <td>
                                <div class="status-pill {{ $account->account_status == 'Open' ? 'pill-open' : 'pill-closed' }}">
                                    {{ $account->account_status ?? 'Unknown' }}
                                </div>
                                <div style="margin-top: 4px; font-weight: 600;">
                                    {{ $account->current_balance ? '$' . number_format($account->current_balance) : '-' }}
                                </div>
                            </td>
                            <td>{{ $account->credit_limit ? '$' . number_format($account->credit_limit) : '-' }}</td>
                            <td>{{ $account->bureau }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif

    <!-- Inquiries -->
    @if($inquiries->count() > 0)
        <div class="data-section">
            <div class="section-header">
                <div class="section-title">
                    <i class="bi bi-search text-purple-500"></i>
                    Hard Inquiries
                </div>
                <span class="section-badge">{{ $inquiries->count() }} Inquiries</span>
            </div>
            
            <div style="overflow-x: auto;">
                <table class="custom-table">
                    <thead>
                        <tr>
                            <th>Creditor</th>
                            <th>Type</th>
                            <th>Date</th>
                            <th>Bureau</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($inquiries as $inquiry)
                        <tr>
                            <td style="font-weight: 600;">{{ $inquiry->creditor_name }}</td>
                            <td>{{ $inquiry->inquiry_type }}</td>
                            <td>{{ $inquiry->inquiry_date ? $inquiry->inquiry_date->format('M d, Y') : '-' }}</td>
                            <td>{{ $inquiry->bureau }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif

    <!-- Public Records -->
    @if($publicRecords->count() > 0)
        <div class="data-section">
            <div class="section-header">
                <div class="section-title">
                    <i class="bi bi-bank text-red-500"></i>
                    Public Records
                </div>
                <span class="section-badge">{{ $publicRecords->count() }} Records</span>
            </div>
            
            <div style="overflow-x: auto;">
                <table class="custom-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Amount</th>
                            <th>Date Filed</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($publicRecords as $record)
                        <tr>
                            <td style="font-weight: 600;">{{ $record->record_type }}</td>
                            <td>
                                <span class="status-pill pill-neg">{{ $record->status }}</span>
                            </td>
                            <td>{{ $record->amount ? '$'.number_format($record->amount) : '-' }}</td>
                            <td>{{ $record->filed_date ? $record->filed_date->format('M d, Y') : '-' }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif
    
     <!-- No Data State -->
    @if($creditScores->count() == 0 && $accounts->count() == 0 && $inquiries->count() == 0)
        <div style="text-align: center; padding: 4rem; background: var(--bg-card); border-radius: 20px; box-shadow: var(--card-shadow);">
            <i class="bi bi-folder2-open" style="font-size: 3rem; color: var(--text-secondary); margin-bottom: 1rem; display: block;"></i>
            <h3 style="font-size: 1.25rem; font-weight: 600; color: var(--text-main);">No Data Parsed</h3>
            <p style="color: var(--text-secondary);">We couldn't extract any data from this report. It might be an unsupported format.</p>
        </div>
    @endif

</div>
@endsection
