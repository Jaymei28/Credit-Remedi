<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AIReportExtractorService
{
    protected $apiKey;
    protected $model = 'gpt-4o'; // More powerful model for better extraction accuracy

    public function __construct()
    {
        $this->apiKey = env('OPENAI_API_KEY');
    }

    /**
     * Extract credit report data using AI
     */
    public function extractFromHTML($htmlContent)
    {
        try {
            // Prepare the prompt for AI extraction
            $prompt = $this->buildExtractionPrompt();
            
            // Call OpenAI API
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Content-Type' => 'application/json',
            ])->timeout(60)->post('https://api.openai.com/v1/chat/completions', [
                'model' => $this->model,
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => $prompt
                    ],
                    [
                        'role' => 'user',
                        'content' => "Extract only the counts of these items from the provided IdentityIQ report:\n\n1. Credit Score Count - Count how many bureaus have credit scores (TransUnion, Experian, Equifax).\n2. Account Count - Count how many total accounts are listed across all bureaus.\n3. Open Account Count - Count how many accounts have status 'Open' or 'Current'.\n4. Hard Inquiry Count - Count how many hard inquiries are listed.\n\nReturn ONLY a JSON object with counts. Here is the report:\n\n" . substr($htmlContent, 0, 50000)
                    ]
                ],
                'temperature' => 0.1, // Low temperature for accuracy
                'response_format' => ['type' => 'json_object']
            ]);

            if ($response->successful()) {
                $result = $response->json();
                $extractedData = json_decode($result['choices'][0]['message']['content'], true);
                
                // Debug logging - log the full response
                Log::info('=== AI EXTRACTION DEBUG ===');
                Log::info('Raw AI Response:', ['content' => $result['choices'][0]['message']['content']]);
                Log::info('Parsed Data Structure:', [
                    'has_personal_info' => isset($extractedData['personal_info']),
                    'has_credit_scores' => isset($extractedData['credit_scores']),
                    'has_accounts' => isset($extractedData['accounts']),
                    'has_inquiries' => isset($extractedData['inquiries']),
                    'has_public_records' => isset($extractedData['public_records']),
                    'has_summary' => isset($extractedData['summary']),
                ]);
                Log::info('Counts:', [
                    'credit_scores' => count($extractedData['credit_scores'] ?? []),
                    'accounts' => count($extractedData['accounts'] ?? []),
                    'inquiries' => count($extractedData['inquiries'] ?? []),
                    'public_records' => count($extractedData['public_records'] ?? []),
                ]);
                
                // Log sample data if available
                if (!empty($extractedData['accounts'])) {
                    Log::info('First Account Sample:', ['account' => $extractedData['accounts'][0]]);
                }
                if (!empty($extractedData['inquiries'])) {
                    Log::info('First Inquiry Sample:', ['inquiry' => $extractedData['inquiries'][0]]);
                }
                
                return [
                    'success' => true,
                    'data' => $extractedData
                ];
            }

            return [
                'success' => false,
                'error' => 'API request failed: ' . $response->body()
            ];

        } catch (\Exception $e) {
            Log::error('AI Extraction Error: ' . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    protected function buildExtractionPrompt()
    {
        return <<<PROMPT
You are an AI that extracts and counts information from IdentityIQ credit reports.

Your ONLY task is to COUNT items in the report. Do NOT extract full details.

## WHAT TO COUNT:

### 1. Credit Score Count
- Count how many bureaus have credit scores listed
- Look for TransUnion, Experian, and Equifax scores
- Each bureau with a score = 1 count
- Maximum possible: 3

### 2. Total Account Count
- Count EVERY account/tradeline in the report
- Include all accounts from all bureaus
- Count each account once (even if it appears on multiple bureaus, count it for each bureau it appears on)
- Include: Credit Cards, Mortgages, Auto Loans, Student Loans, Collections, Medical, etc.

### 3. Open Account Count
- Count only accounts with status "Open", "Current", or "Active"
- Do NOT count Closed, Paid Off, or Charge-off accounts

### 4. Hard Inquiry Count
- Count ONLY hard inquiries (not soft inquiries)
- Count each hard inquiry once

## OUTPUT FORMAT (JSON):

Return ONLY this JSON structure with counts:

{
  "credit_scores": [
    {"bureau": "TransUnion", "score": 720, "score_date": "2025-12-12", "lender_rank": "Good"},
    {"bureau": "Experian", "score": 715, "score_date": "2025-12-12", "lender_rank": "Good"},
    {"bureau": "Equifax", "score": 718, "score_date": "2025-12-12", "lender_rank": "Good"}
  ],
  "accounts": [],
  "inquiries": [],
  "public_records": [],
  "summary": {
    "total_accounts": 0,
    "open_accounts": 0,
    "closed_accounts": 0,
    "negative_accounts": 0,
    "total_inquiries": 0,
    "total_public_records": 0
  }
}

## CRITICAL RULES:

1. **ACCURACY**: Count carefully. Double-check your counts.

2. **CREDIT SCORES**: 
   - Extract all 3 credit scores with bureau name, score value, and rank
   - Rank based on: 750+ = Excellent, 700-749 = Good, 650-699 = Fair, 600-649 = Poor, <600 = Very Poor

3. **ACCOUNTS**: 
   - Count ALL accounts you see
   - Don't skip any
   - summary.total_accounts = total count
   - summary.open_accounts = count of open/current accounts only

4. **INQUIRIES**:
   - Count ONLY hard inquiries
   - summary.total_inquiries = hard inquiry count

5. **LEAVE ARRAYS EMPTY**:
   - accounts = [] (empty array)
   - inquiries = [] (empty array)
   - public_records = [] (empty array)
   - We only need the counts in summary

6. **JSON ONLY**:
   - Return ONLY valid JSON
   - No explanations, no markdown, no extra text

## EXAMPLE:

If you see:
- 3 credit scores (TU: 720, EXP: 715, EQ: 718)
- 12 total accounts (8 open, 4 closed)
- 5 hard inquiries

Return:
{
  "credit_scores": [
    {"bureau": "TransUnion", "score": 720, "score_date": "2025-12-12", "lender_rank": "Good"},
    {"bureau": "Experian", "score": 715, "score_date": "2025-12-12", "lender_rank": "Good"},
    {"bureau": "Equifax", "score": 718, "score_date": "2025-12-12", "lender_rank": "Good"}
  ],
  "accounts": [],
  "inquiries": [],
  "public_records": [],
  "summary": {
    "total_accounts": 12,
    "open_accounts": 8,
    "closed_accounts": 4,
    "negative_accounts": 0,
    "total_inquiries": 5,
    "total_public_records": 0
  }
}

REMEMBER: Only count items. Be accurate. Return valid JSON.

PROMPT;
    }

    /**
     * Validate extracted data structure
     */
    public function validateExtractedData($data)
    {
        $required = ['credit_scores', 'accounts', 'inquiries', 'summary'];
        
        foreach ($required as $key) {
            if (!isset($data[$key])) {
                return false;
            }
        }
        
        return true;
    }
}
